namespace TableReservation.Models;

public class Tables
{
    public int Table_Id { get; set; }
    public string Table_number { get; set; }
    public string num_chairs { get; set; }
    public string reserved { get; set; }
}